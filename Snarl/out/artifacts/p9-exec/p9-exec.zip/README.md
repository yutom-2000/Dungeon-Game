To run the game:

First ensure that the snarlServer is located in the same directory as the .levels file that specifies the levels to load for this game instance.
Then, execute ./snarlServer with the necessary command line arguments you wish.

Then, each client execute the ./snarlClient executable to launch a new instance of the client.
Ensure that the connection info is the same between servers, so that the connection is able to be made.

Then to play the game, from the client, input the desired positions when prompted for a move, in the form "[y, x]", where y is the row and x is the column of the position the player desires to move to.
